package mvcpackage.model.bean;

public class LoginBean {
	private String uname;
	private String upass;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPassword() {
		return upass;
	}

	public void setPassword(String upass) {
		this.upass = upass;
	}

}
