package mvcpackage.model.bean;

public class Comment {
	protected int Comid;
	protected int Postid;
	protected String ComText;
	
	public Comment() {}
	public Comment(int a, int b, String c) {
		this.Comid = a;
		this.Postid = b;
		this.ComText = c;
	}
	public Comment(int b, String c) {
		this.Postid = b;
		this.ComText = c;
		}
	public int getComid() {
		return Comid;
	}
	public void setComid(int comid) {
		Comid = comid;
	}
	public int getPostid() {
		return Postid;
	}
	public void setPostid(int postid) {
		Postid = postid;
	}
	public String getComText() {
		return ComText;
	}
	public void setComText(String comText) {
		ComText = comText;
	}
}
