package mvcpackage.model.bean;

public class Snippet {
	public static void main(String[] args) {
		
	}
}

