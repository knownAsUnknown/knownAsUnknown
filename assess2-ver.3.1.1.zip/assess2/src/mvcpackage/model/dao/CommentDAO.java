package mvcpackage.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import mvcpackage.model.bean.Comment;
import mvcpackage.model.bean.Post;

public class CommentDAO {
	//Define instance variables
		private String DBURL = "jdbc:mysql://localhost:3306/blog";
		private String DBUsername = "root";
		private String DBPassword = "abc123";
		private String INSERTCOMMENTSSQL = "INSERT INTO Comments (comments_id, post_id, comments_text) VALUES " + " (?, ?, ?);";
		private String SELECTCOMMENTSID = "select comments_id, comments_text from Comments where comments_id =?";
		private String SELECTALLCOMMENTS = "select * from Comments inner join post on comments.post_id = post.post_id where post_id=?";
		private String DELETECOMMENTSSQL = "delete from comments where comments_id = ?";
		private String UPDATECOMMENTSSQL = "update Comments set comments_text = ? where comments_id=?;";

		//constructor
		public CommentDAO() {}
		
		protected Connection getConnection() {
			Connection connection = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection = DriverManager.getConnection(DBURL, DBUsername, DBPassword);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return connection;	
		}
		
		public void insertComments(Comment c) throws SQLException {
			System.out.println(INSERTCOMMENTSSQL);
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			// try-with-resource statement will auto close the connection.
			try {
				connection = getConnection();
				preparedStatement = connection.prepareStatement(INSERTCOMMENTSSQL);
				preparedStatement.setInt(1, c.getPostid());
				preparedStatement.setString(2, c.getComText());
				System.out.println(preparedStatement);
				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				printSQLException(e);
			} finally {
				finallySQLException(connection,preparedStatement,null);
			}
		}
		
		public Comment selectComment(int c) {
			Comment comment = null;
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			ResultSet rs=null;
			// Step 1: Establishing a Connection
			try {
				connection = getConnection();
				// Step 2:Create a statement using connection object
				preparedStatement = connection.prepareStatement(SELECTCOMMENTSID);
				preparedStatement.setInt(1, c);
				System.out.println(preparedStatement);
				// Step 3: Execute the query or update query
				rs = preparedStatement.executeQuery();
				// Step 4: Process the ResultSet object.
				while (rs.next()) {
					int comid = rs.getInt("comments_id");
					int pid = rs.getInt("post_id");
					String Ctext = rs.getString("comments_text");
					
					comment = new Comment(comid, pid, Ctext);
				}
			} catch (SQLException e) {
				printSQLException(e);
			}
			finally {
				finallySQLException(connection,preparedStatement,rs);
			}
			return comment;
		}
		
		public  List < Comment > selectAllComments(int id) {
			//Post post = null;
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			ResultSet rs=null;
			// using try-with-resources to avoid closing resources (boiler plate code)
			List < Comment > comments = new ArrayList < > ();
			// Step 1: Establishing a Connection
			try {
				connection = getConnection();
				// Step 2:Create a statement using connection object
				preparedStatement = connection.prepareStatement(SELECTALLCOMMENTS);
				preparedStatement.setInt(1, id);
				System.out.println(preparedStatement);
				// Step 3: Execute the query or update query
				rs = preparedStatement.executeQuery();
				// Step 4: Process the ResultSet object.
				while (rs.next()) {
					int comid = rs.getInt("comments_id");
					int pid = rs.getInt("post_id");
					String Ctext = rs.getString("comments_text");
					

					comments.add(new Comment(comid, pid, Ctext));
				}
			} catch (SQLException e) {
				printSQLException(e);
			}
			finally {
				finallySQLException(connection,preparedStatement,rs);
			}
			return comments;
		}
		
		public boolean deletePost(int id) throws SQLException {
			boolean commentDeleted = false;
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			try {
				connection = getConnection();
				preparedStatement = connection.prepareStatement(DELETECOMMENTSSQL);
				preparedStatement.setInt(1, id);
				commentDeleted = preparedStatement.executeUpdate() > 0 ? true:false;
			}
			finally {
				finallySQLException(connection,preparedStatement,null);
			}
			return commentDeleted;
		}
		
		public boolean updateComment (Comment comment) throws SQLException {
			boolean commentUpdated = false;
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			try {
				connection = getConnection();
				preparedStatement = connection.prepareStatement(UPDATECOMMENTSSQL);
				preparedStatement.setString(1, comment.getComText());
				commentUpdated = preparedStatement.executeUpdate() > 0 ? true:false;
			}
			catch (SQLException e) {
				printSQLException (e);
			}
			finally {
				finallySQLException(connection,preparedStatement,null);
			}
			return commentUpdated;
		}
		
		private void printSQLException(SQLException ex) {
			for (Throwable e: ex) {
				if (e instanceof SQLException) {
					e.printStackTrace(System.err);
					System.err.println("SQLState: " + ((SQLException) e).getSQLState());
					System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
					System.err.println("Message: " + e.getMessage());
					Throwable t = ex.getCause();
					while (t != null) {
						System.out.println("Cause: " + t); t = t.getCause();
					}
				}
			}
		}
		
		private void finallySQLException(Connection c, PreparedStatement p, ResultSet r){
			if (r != null) {
				try {
					r.close();
				} catch (Exception e) {}
				r = null;
			}
			if (p != null) {
				try {
					p.close();
				} catch (Exception e) {}
				p = null;
			}
			if (c != null) {
				try {
					c.close();
				} catch (Exception e) {
					c = null;
				}
			}
		}
}