package mvcpackage.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import mvcpackage.model.bean.Post;

public class PostDAO {
	//Define instance variables
		private String DBURL = "jdbc:mysql://localhost:3306/blog";
		private String DBUsername = "root";
		private String DBPassword = "mysql";
		private String INSERTPOSTSQL = "INSERT INTO Post (cat_id, post_title, post_keywords, post_body, published) VALUES " + " (?, ?, ?, ?, ?);";
		private String SELECTPOSTID = "select post_id, cat_id, post_title,post_keywords,post_body, published from Post where post_id =?";
		private String SELECTALLPOSTS = "select * from Post";
		private String DELETEPOSTSQL = "delete from Post where post_id = ?;";
		private String UPDATEPOSTSQL = "update Post set post_title = ?,post_keywords= ?, post_body =?, published =? where post_id = ?;";
		private String GETPOSTCOUNT = "select count(*) from Post;";
		
		//constructor
		public PostDAO() {}
		
		protected Connection getConnection() {
			Connection connection = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection = DriverManager.getConnection(DBURL, DBUsername, DBPassword);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return connection;
		}
		
		public void insertPost(Post p) throws SQLException {
			System.out.println(INSERTPOSTSQL);
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			// try-with-resource statement will auto close the connection.
			try {
				connection = getConnection();
				preparedStatement = connection.prepareStatement(INSERTPOSTSQL);
				preparedStatement.setInt(1, p.getCid());
				preparedStatement.setString(2, p.getPtitle());
				preparedStatement.setString(3, p.getPkeywords());
				preparedStatement.setString(4, p.getPbody());
				preparedStatement.setInt(5, p.getPpublish());
				System.out.println(preparedStatement);
				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				printSQLException(e);
			} finally {
				finallySQLException(connection,preparedStatement,null);
			}
		}
		
		public Post selectPost(int p) {
			Post post = null;
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			ResultSet rs=null;
			// Step 1: Establishing a Connection
			try {
				connection = getConnection();
				// Step 2:Create a statement using connection object
				preparedStatement = connection.prepareStatement(SELECTPOSTID);
				preparedStatement.setInt(1, p);
				System.out.println(preparedStatement);
				// Step 3: Execute the query or update query
				rs = preparedStatement.executeQuery();
				// Step 4: Process the ResultSet object.
				while (rs.next()) {
					int Cid = rs.getInt("cat_id");
					String Ptitle = rs.getString("post_title");
					String Pkeywords = rs.getString("post_keywords");
					String Pbody= rs.getString("post_body");
					int Ppublish = rs.getInt("published");
					post = new Post(p, Cid, Ptitle, Pkeywords, Pbody, Ppublish);
				}
			} catch (SQLException e) {
				printSQLException(e);
			}
			finally {
				finallySQLException(connection,preparedStatement,rs);
			}
			return post;
		}
		
		public List < Post > selectAllPosts() {
			//Post post = null;
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			ResultSet rs=null;
			// using try-with-resources to avoid closing resources (boiler plate code)
			List < Post > posts = new ArrayList < > ();
			// Step 1: Establishing a Connection
			try {
				connection = getConnection();
				// Step 2:Create a statement using connection object
				preparedStatement = connection.prepareStatement(SELECTALLPOSTS);
				System.out.println(preparedStatement);
				// Step 3: Execute the query or update query
				rs = preparedStatement.executeQuery();
				// Step 4: Process the ResultSet object.
				while (rs.next()) {
					int Pid = rs.getInt("post_id");
					int Cid = rs.getInt("cat_id");
					String Ptitle = rs.getString("post_title");
					String Pkeywords = rs.getString("post_keywords");
					String Pbody= rs.getString("post_body");
					int Ppublish = rs.getInt("published");
					String Pcreated = rs.getString("created_at");
					String Pupdated = rs.getString("updated_at");

					posts.add(new Post(Pid, Cid, Ptitle, Pkeywords, Pbody, Ppublish, Pcreated, Pupdated));
				}
			} catch (SQLException e) {
				printSQLException(e);
			}
			finally {
				finallySQLException(connection,preparedStatement,rs);
			}
			return posts;
		}
		
		public boolean deletePost(int id) throws SQLException {
			boolean postDeleted = false;
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			try {
				connection = getConnection();
				preparedStatement = connection.prepareStatement(DELETEPOSTSQL);
				preparedStatement.setInt(1, id);
				postDeleted = preparedStatement.executeUpdate() > 0 ? true:false;
			}
			finally {
				finallySQLException(connection,preparedStatement,null);
			}
			return postDeleted;
		}
		
		public boolean updatePost (Post post) throws SQLException {
			boolean postUpdated = false;
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			try {
				connection = getConnection();
				preparedStatement = connection.prepareStatement(UPDATEPOSTSQL);
				preparedStatement.setString(1, post.getPtitle());
				preparedStatement.setString(2, post.getPkeywords());
				preparedStatement.setString(3, post.getPbody());
				preparedStatement.setInt(3, post.getPpublish());
				postUpdated = preparedStatement.executeUpdate() > 0 ? true:false;
			}
			catch (SQLException e) {
				printSQLException (e);
			}
			finally {
				finallySQLException(connection,preparedStatement,null);
			}
			return postUpdated;
		}
		
		public int countPost() {
			int postCount = 0;
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			ResultSet rs=null;
			// Step 1: Establishing a Connection
			try {
				connection = getConnection();
				// Step 2:Create a statement using connection object
				preparedStatement = connection.prepareStatement(GETPOSTCOUNT);
				System.out.println(preparedStatement);
				// Step 3: Execute the query or update query
				rs = preparedStatement.executeQuery();
				// Step 4: Process the ResultSet object.
				while (rs.next()) {
					postCount = rs.getInt("count('post_id')");
				}
			} catch (SQLException e) {
				printSQLException(e);
			}
			finally {
				finallySQLException(connection,preparedStatement,rs);
			}
			return postCount;
		}
		
		private void printSQLException(SQLException ex) {
			for (Throwable e: ex) {
				if (e instanceof SQLException) {
					e.printStackTrace(System.err);
					System.err.println("SQLState: " + ((SQLException) e).getSQLState());
					System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
					System.err.println("Message: " + e.getMessage());
					Throwable t = ex.getCause();
					while (t != null) {
						System.out.println("Cause: " + t); t = t.getCause();
					}
				}
			}
		}
		
		private void finallySQLException(Connection c, PreparedStatement p, ResultSet r){
			if (r != null) {
				try {
					r.close();
				} catch (Exception e) {}
				r = null;
			}
			if (p != null) {
				try {
					p.close();
				} catch (Exception e) {}
				p = null;
			}
			if (c != null) {
				try {
					c.close();
				} catch (Exception e) {
					c = null;
				}
			}
		}
}
