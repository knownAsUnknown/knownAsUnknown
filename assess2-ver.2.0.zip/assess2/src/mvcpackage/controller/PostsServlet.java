package mvcpackage.controller;
import mvcpackage.model.bean.Post;
import mvcpackage.model.dao.PostDAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PostsServlet
 */
@WebServlet("/")
public class PostsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PostDAO postDAO;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PostsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void init() {
    	postDAO = new PostDAO();
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		 try {
			 switch (action) {
			 case "/new":
				 showNewPost(request, response);
				 break;
			 case "/insert":
				 insertPost(request, response);
				 break;
			 case "/delete":
				 deletePost(request, response);
				 break;
			 case "/edit":
				 showEditPost(request, response);
				 break;
			 case "/update":
				 updatePost(request, response);
				 break;
			 default:
				 listPost(request, response);
				 break;
			 }
		 } catch (SQLException ex) {
			 throw new ServletException(ex);
		 }
	}
	
	private void listPost(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
		List < Post > listPost = postDAO.selectAllPosts();
		request.setAttribute("listPost", listPost);
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
	}
	
	private void showNewPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("edit.jsp");
		dispatcher.forward(request, response);
	}
	
	private void insertPost(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int Pid= Integer.parseInt(request.getParameter("pid"));
		int Cid= Integer.parseInt(request.getParameter("cid"));
		String Ptitle = request.getParameter("title");
		String Pkeywords= request.getParameter("keywords");
		String Pbody= request.getParameter("body");
		int Ppublish= Integer.parseInt(request.getParameter("published"));
		String Pcreated= request.getParameter("created");
		String Pupdated= request.getParameter("updated");
		Post p = new Post(Pid, Cid, Ptitle, Pkeywords, Pbody, Ppublish, Pcreated, Pupdated);
		postDAO.insertPost(p);
		response.sendRedirect("list");
	}
	
	private void showEditPost(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Post existingPost = postDAO.selectPost(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("edit.jsp");
		request.setAttribute("employee", existingPost);
		dispatcher.forward(request, response);
	}
	
	private void updatePost(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int Pid= Integer.parseInt(request.getParameter("pid"));
		int Cid= Integer.parseInt(request.getParameter("cid"));
		String Ptitle = request.getParameter("title");
		String Pkeywords= request.getParameter("keywords");
		String Pbody= request.getParameter("body");
		int Ppublish= Integer.parseInt(request.getParameter("published"));
		String Pcreated= request.getParameter("created");
		String Pupdated= request.getParameter("updated");
		Post p = new Post(Pid, Cid, Ptitle, Pkeywords, Pbody, Ppublish, Pcreated, Pupdated);
		postDAO.updatePost(p);
		response.sendRedirect("list");
	}
	
	private void deletePost(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("pid"));
		postDAO.deletePost(id);
		response.sendRedirect("list");
	}

}
