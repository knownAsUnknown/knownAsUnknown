package mvcpackage.model.bean;

import java.util.*;

public class Category {
	private int cid;
	private String category;
	private Hashtable<Integer, String> hash = new Hashtable<Integer, String>();
	
	public Category() {}
	
	public Category(int c, String cat) {
		this.cid = c;
		this.category = cat;
		this.hash.put(c, cat);
	}
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
}
