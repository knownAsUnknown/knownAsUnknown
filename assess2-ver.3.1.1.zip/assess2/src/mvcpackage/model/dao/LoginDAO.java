package mvcpackage.model.dao;

import mvcpackage.model.bean.LoginBean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class LoginDAO {
	public static boolean validate(LoginBean loginBean) throws ClassNotFoundException {
		boolean status = false;
		PreparedStatement ps = null;
		Connection conn = null;
		ResultSet rs = null;
			
		Class.forName("com.mysql.jdbc.Driver");

		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/blog", "root", "mysql");
			
			// Step 2:Create a statement using connection object
			ps = conn.prepareStatement("select * from adminuser where user_name = ? and user_password = ?"); 
			ps.setString(1, loginBean.getUname());
			ps.setString(2, loginBean.getPassword());

			//System.out.println(ps);
			rs = ps.executeQuery();
			status = rs.next();

		} catch (SQLException e) {
			e.printStackTrace(System.err);
			System.err.println("SQLState: " + ((SQLException) e).getSQLState());
			System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
			System.err.println("Message: " + e.getMessage());
			
		}
		finally {
			if (rs != null)	{
				try {
					rs.close();
				} catch (Exception e) {}
					rs = null;
				}
		
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {}
					ps = null;
				}
		
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
					conn = null;
				}
			}
		}
		return status;
	}
}
