package mvcpackage.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import mvcpackage.model.bean.Category;
import mvcpackage.model.bean.Post;

public class CategoryDAO {
	//Define instance variables
			private String DBURL = "jdbc:mysql://localhost:3306/blog";
			private String DBUsername = "root";
			private String DBPassword = "mysql";
			private String INSERTCATEGORYSQL = "INSERT INTO Category (cat_id, cat_title) VALUES " + " (?, ?);";
			private String SELECTCATEGORYID = "select cat_id, cat_title from Category where cat_id =?";
			private String SELECTALLCATEGORIES = "select * from Category";
			private String SELECTCATEGORYIDPID = "select cat_id, cat_title from Category inner join Post on Category.cat_id = Post.cat_id where Post.cat_id = ?";
			private String DELETECATEGORYSQL = "delete from Category where cat_id = ?;";
			private String UPDATECATEGORYSQL = "update Post set cat_title = ? where cat_id = ?;";
			private String GETCATEGORYCOUNT = "select count(*) from Category;";
			
			//constructor
			public CategoryDAO() {}
			
			protected Connection getConnection() {
				Connection connection = null;
				try {
					Class.forName("com.mysql.jdbc.Driver");
					connection = DriverManager.getConnection(DBURL, DBUsername, DBPassword);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return connection;
			}
			
			public void insertCategory(Category c) throws SQLException {
				System.out.println(INSERTCATEGORYSQL);
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				// try-with-resource statement will auto close the connection.
				try {
					connection = getConnection();
					preparedStatement = connection.prepareStatement(INSERTCATEGORYSQL);
					preparedStatement.setInt(1, c.getCid());
					preparedStatement.setString(2, c.getCategory());
					System.out.println(preparedStatement);
					preparedStatement.executeUpdate();
				} catch (SQLException e) {
					printSQLException(e);
				} finally {
					finallySQLException(connection,preparedStatement,null);
				}
			}
			
			public Category selectCategory(int c) {
				Category category = null;
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				ResultSet rs=null;
				// Step 1: Establishing a Connection
				try {
					connection = getConnection();
					// Step 2:Create a statement using connection object
					preparedStatement = connection.prepareStatement(SELECTCATEGORYID);
					preparedStatement.setInt(1, c);
					System.out.println(preparedStatement);
					// Step 3: Execute the query or update query
					rs = preparedStatement.executeQuery();
					// Step 4: Process the ResultSet object.
					while (rs.next()) {
						int Cid = rs.getInt("cat_id");
						String Ccategory = rs.getString("cat_title");
						category = new Category(Cid, Ccategory);
					}
				} catch (SQLException e) {
					printSQLException(e);
				}
				finally {
					finallySQLException(connection,preparedStatement,rs);
				}
				return category;
			}

			
			// This will override the previous when there is a Post parameter entered
			public Category selectCategory(Post p) {
				Category category = null;
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				ResultSet rs=null;
				// Step 1: Establishing a Connection
				try {
					connection = getConnection();
					// Step 2:Create a statement using connection object
					preparedStatement = connection.prepareStatement(SELECTCATEGORYIDPID);
					preparedStatement.setInt(1, p.getCid());
					System.out.println(preparedStatement);
					// Step 3: Execute the query or update query
					rs = preparedStatement.executeQuery();
					// Step 4: Process the ResultSet object.
					while (rs.next()) {
						int Cid = rs.getInt("cat_id");
						String Ccategory = rs.getString("cat_title");
						category = new Category(Cid, Ccategory);
					}
				} catch (SQLException e) {
					printSQLException(e);
				}
				finally {
					finallySQLException(connection,preparedStatement,rs);
				}
				return category;
			}
			
			public List < Category > selectAllCategories() {
				//Post post = null;
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				ResultSet rs=null;
				// using try-with-resources to avoid closing resources (boiler plate code)
				List < Category > categories = new ArrayList < > ();
				// Step 1: Establishing a Connection
				try {
					connection = getConnection();
					// Step 2:Create a statement using connection object
					preparedStatement = connection.prepareStatement(SELECTALLCATEGORIES);
					System.out.println(preparedStatement);
					// Step 3: Execute the query or update query
					rs = preparedStatement.executeQuery();
					// Step 4: Process the ResultSet object.
					while (rs.next()) {
						int Cid = rs.getInt("cat_id");
						String Ccategory = rs.getString("cat_title");
						categories.add(new Category(Cid, Ccategory));
					}
				} catch (SQLException e) {
					printSQLException(e);
				}
				finally {
					finallySQLException(connection,preparedStatement,rs);
				}
				return categories;
			}
			
			public boolean deleteCategory(int id) throws SQLException {
				boolean postDeleted = false;
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				try {
					connection = getConnection();
					preparedStatement = connection.prepareStatement(DELETECATEGORYSQL);
					preparedStatement.setInt(1, id);
					postDeleted = preparedStatement.executeUpdate() > 0 ? true:false;
				}
				finally {
					finallySQLException(connection,preparedStatement,null);
				}
				return postDeleted;
			}
			
			public boolean updateCategory (Category category) throws SQLException {
				boolean postUpdated = false;
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				try {
					connection = getConnection();
					preparedStatement = connection.prepareStatement(UPDATECATEGORYSQL);
					preparedStatement.setString(1, category.getCategory());
					preparedStatement.setInt(2, category.getCid());
					postUpdated = preparedStatement.executeUpdate() > 0 ? true:false;
				}
				catch (SQLException e) {
					printSQLException (e);
				}
				finally {
					finallySQLException(connection,preparedStatement,null);
				}
				return postUpdated;
			}
			
			public int countCategory() {
				int postCount = 0;
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				ResultSet rs=null;
				// Step 1: Establishing a Connection
				try {
					connection = getConnection();
					// Step 2:Create a statement using connection object
					preparedStatement = connection.prepareStatement(GETCATEGORYCOUNT);
					System.out.println(preparedStatement);
					// Step 3: Execute the query or update query
					rs = preparedStatement.executeQuery();
					// Step 4: Process the ResultSet object.
					while (rs.next()) {
						postCount = rs.getInt("count('cat_id')");
					}
				} catch (SQLException e) {
					printSQLException(e);
				}
				finally {
					finallySQLException(connection,preparedStatement,rs);
				}
				return postCount;
			}
			
			private void printSQLException(SQLException ex) {
				for (Throwable e: ex) {
					if (e instanceof SQLException) {
						e.printStackTrace(System.err);
						System.err.println("SQLState: " + ((SQLException) e).getSQLState());
						System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
						System.err.println("Message: " + e.getMessage());
						Throwable t = ex.getCause();
						while (t != null) {
							System.out.println("Cause: " + t); t = t.getCause();
						}
					}
				}
			}
			
			private void finallySQLException(Connection c, PreparedStatement p, ResultSet r){
				if (r != null) {
					try {
						r.close();
					} catch (Exception e) {}
					r = null;
				}
				if (p != null) {
					try {
						p.close();
					} catch (Exception e) {}
					p = null;
				}
				if (c != null) {
					try {
						c.close();
					} catch (Exception e) {
						c = null;
					}
				}
			}

}
