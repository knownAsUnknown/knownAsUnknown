package mvcpackage.model.bean;

public class Post {
	protected int Pid;
	protected int Cid;
	protected String Ptitle;
	protected String Pkeywords;
	protected String Pbody;
	protected int Ppublish;
	protected String Pcreated;
	protected String Pupdated;

	public Post() {}
	public Post(int i, String t, int p) {
		this.Pid = i;
		this.Ptitle = t;
		this.Ppublish = p;

	}
	public Post(int i, int c, String t, String k, int p) {
		this.Pid = i;
		this.Cid = c;
		this.Ptitle = t;
		this.Pkeywords = k;
		this.Ppublish = p;

	}
	public Post(int i, int c, String t, String k, String b, int p) {
		this.Pid = i;
		this.Cid = c;
		this.Ptitle = t;
		this.Pkeywords = k;
		this.Pbody = b;
		this.Ppublish = p;
	}
	public Post(int c, String t, String k, String b, int p) {
		this.Cid = c;
		this.Ptitle = t;
		this.Pkeywords = k;
		this.Pbody = b;
		this.Ppublish = p;
	}
	
	public Post(int i, int c, String t, String k, String b, int p, String up) {
		this.Pid = i;
		this.Cid = c;
		this.Ptitle = t;
		this.Pkeywords = k;
		this.Pbody = b;
		this.Ppublish = p;
		this.Pupdated = up;
	}

	public Post(int i, int c, String t, String k, String b, int p, String cr, String up) {
		this.Pid = i;
		this.Cid = c;
		this.Ptitle = t;
		this.Pkeywords = k;
		this.Pbody = b;
		this.Ppublish = p;
		this.Pcreated = cr;
		this.Pupdated = up;
	}
	public int getPid() {
		return Pid;
	}
	
	public void setPid(int Pid) {
		this.Pid = Pid;
	}
	
	public String getPtitle() {
		return Ptitle;
	}
	
	public void setPtitle(String t) {
		this.Ptitle = t;
	}

	public int getCid() {
		return Cid;
	}
	
	public void setCid(int c) {
		this.Cid = c;
	}
	
	public String getPkeywords() {
		return Pkeywords;
	}
	
	public void setPkeywords(String k) {
		this.Pkeywords = k;
	}

	public String getPbody() {
		return Pbody;
	}
	
	public void setPbody(String b) {
		this.Pbody = b;
	}
	public int getPpublish() {
		return Ppublish;
	}
	
	public void setPpublish(int p) {
		this.Ppublish= p;
	}
	public String getPcreated() {
		return Pcreated;
	}
	
	public void setPcreated(String cc) {
		this.Pcreated= cc;
	}
	
	public String getPupdated() {
		return Pupdated;
	}
	
	public void setPupdated(String uu) {
		this.Pupdated= uu;
	}
}
