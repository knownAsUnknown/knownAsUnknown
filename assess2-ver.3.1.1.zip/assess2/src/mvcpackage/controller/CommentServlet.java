package mvcpackage.controller;
import mvcpackage.model.bean.Comment;
import mvcpackage.model.bean.Post;
import mvcpackage.model.dao.PostDAO;
import mvcpackage.model.dao.CommentDAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CommentServlet
 */
@WebServlet("/CommentServlet")
public class CommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private CommentDAO commentDAO;
    private PostDAO postDAO;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CommentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    public void init() {
    	commentDAO = new CommentDAO();
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		try {
			 switch (action) {
			 case "/insert":
				 insertComment(request, response);
				 break;
			 case "/new":
				 showNewComment(request, response);
				 break;
			 case "/delete":
				 deleteComment(request, response);
				 break;
			 case "/edit":
				 showEditComment(request, response);
				 break;
			 case "/update":
				 updateComment(request, response);
				 break;
			 default:
				 listComment(request, response);
				 break;
			 }
		 } catch (SQLException ex) {
			 throw new ServletException(ex);
		 }
	}
	private void listComment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
		int id = Integer.parseInt(request.getParameter("post_id"));
		List < Comment > listComment = commentDAO.selectAllComments(id);
		
		request.setAttribute("listComment", listComment);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Comment.jsp");
		dispatcher.forward(request, response);
	}
	
	private void deleteComment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("comments_id"));
		commentDAO.deletePost(id);
		response.sendRedirect("list");
	}
	
	private void updateComment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int Cid= Integer.parseInt(request.getParameter("post_id"));
		int Pid= Integer.parseInt(request.getParameter("comments_id"));
		String Comtext = request.getParameter("comments_text");
		
		Comment c = new Comment(Cid, Pid, Comtext);
		commentDAO.updateComment(c);
		response.sendRedirect("list");
	}

	private void showEditComment(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("cid"));
		Comment existingComment = commentDAO.selectComment(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("comment.jsp");
		request.setAttribute("comment", existingComment);
		dispatcher.forward(request, response);
	
	}
		private void showNewComment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			RequestDispatcher dispatcher = request.getRequestDispatcher("editComment.jsp");
			dispatcher.forward(request, response);
}
		
		private void insertComment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
			int Cid= Integer.parseInt(request.getParameter("Comid"));
			int Pid= Integer.parseInt(request.getParameter("Postid"));
			String Ctext = request.getParameter("ComText");
			
			Comment c = new Comment(Cid, Pid, Ctext);
			commentDAO.insertComments(c);
			response.sendRedirect("list");
}
}