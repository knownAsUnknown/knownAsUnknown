package mvcpackage.controller;
import mvcpackage.model.bean.Post;
import mvcpackage.model.dao.PostDAO;
import mvcpackage.model.bean.Category;
import mvcpackage.model.dao.CategoryDAO;
import mvcpackage.model.bean.Comment;
import mvcpackage.model.dao.CommentDAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PostsServlet
 */
@WebServlet("/")
public class PostsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PostDAO postDAO;
	private CategoryDAO categoryDAO;
	private CommentDAO commentDAO;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PostsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void init() {
    	postDAO = new PostDAO();
    	categoryDAO = new CategoryDAO();
    	commentDAO = new CommentDAO();
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		 try {
			 switch (action) {
			 case "/new":
				 listCategory(request, response);
				 showNewPost(request, response);
				 break;
			 case "/insert":
				 insertPost(request, response);
				 break;
			 case "/delete":
				 deletePost(request, response);
				 break;
			 case "/edit":
				 listCategory(request, response);
				 showEditPost(request, response);
				 break;
			 case "/update":
				 updatePost(request, response);
				 break;
			 case "/comment":
				 listComment(request, response);
				 showComment(request, response);
				 break;
			 case "/newComment":
				 listCategory(request, response);
				 showNewComment(request, response);
				 break;
			 case "/insertComment":
				 insertComment(request, response);
				 break;
			 case "/deleteComment":
				 deleteComment(request, response);
				 break;
			 case "/editComment":
				 listCategory(request, response);
				 showEditComment(request, response);
				 break;
			 case "/updateComment":
				 updateComment(request, response);
				 break;
			 default:
				 listPost(request, response);
				 break;
			 }
		 } catch (SQLException ex) {
			 throw new ServletException(ex);
		 }
	}
	
	
	//// THIS IS THE POST SECTION ////
	
	private void listPost(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
		List < Post > listPost = postDAO.selectAllPosts();
		request.setAttribute("listPost", listPost);
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
	}
	
	private void listCategory(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
		List < Category > listCategory = categoryDAO.selectAllCategories();
		request.setAttribute("listCategory", listCategory);
	}
	
	private void listComment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
		int id = Integer.parseInt(request.getParameter("post_id"));
		List < Comment > listComment = commentDAO.selectAllComments(id);
		
		request.setAttribute("listComment", listComment);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Comment.jsp");
		dispatcher.forward(request, response);
	}
	
	private void showComment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("comments.jsp");
		dispatcher.forward(request, response);
	}
	
	private void showNewPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("edit.jsp");
		dispatcher.forward(request, response);
	}
	
	private void insertPost(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int Cid= Integer.parseInt(request.getParameter("cid"));
		String Ptitle = request.getParameter("title");
		String Pkeywords= request.getParameter("keywords");
		String Pbody= request.getParameter("body");
		int Ppublish= Integer.parseInt(request.getParameter("published"));
		Post p = new Post(Cid, Ptitle, Pkeywords, Pbody, Ppublish);
		postDAO.insertPost(p);
		response.sendRedirect("list");
	}
	
	private void showEditPost(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Post existingPost = postDAO.selectPost(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("edit.jsp");
		request.setAttribute("post", existingPost);
		dispatcher.forward(request, response);
	}
	
	private void updatePost(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int Pid= Integer.parseInt(request.getParameter("id"));
		int Cid= Integer.parseInt(request.getParameter("cid"));
		String Ptitle = request.getParameter("title");
		String Pkeywords= request.getParameter("keywords");
		String Pbody= request.getParameter("body");
		int Ppublish= Integer.parseInt(request.getParameter("published"));
		String Pupdated= request.getParameter("updated");
		Post p = new Post(Pid, Cid, Ptitle, Pkeywords, Pbody, Ppublish, Pupdated);
		postDAO.updatePost(p);
		response.sendRedirect("list");
	}
	
	private void deletePost(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		postDAO.deletePost(id);
		response.sendRedirect("list");
	}
	
	//// END POST SECTION ////
	
	
	//// THIS IS THE COMMENTS SECTION ////
	private void deleteComment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("comments_id"));
		commentDAO.deletePost(id);
		response.sendRedirect("list");
	}
	
	private void updateComment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int Cid= Integer.parseInt(request.getParameter("post_id"));
		int Pid= Integer.parseInt(request.getParameter("comments_id"));
		String Comtext = request.getParameter("comments_text");
		
		Comment c = new Comment(Cid, Pid, Comtext);
		commentDAO.updateComment(c);
		response.sendRedirect("list");
	}

	private void showEditComment(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("cid"));
		Comment existingComment = commentDAO.selectComment(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("comment.jsp");
		request.setAttribute("post", existingComment);
		dispatcher.forward(request, response);
	
	}
		private void showNewComment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			RequestDispatcher dispatcher = request.getRequestDispatcher("editComment.jsp");
			dispatcher.forward(request, response);
}
		
		private void insertComment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
			int Cid= Integer.parseInt(request.getParameter("Comid"));
			int Pid= Integer.parseInt(request.getParameter("Postid"));
			String Ctext = request.getParameter("ComText");
			
			Comment c = new Comment(Cid, Pid, Ctext);
			commentDAO.insertComments(c);
			response.sendRedirect("list");
}
		
		//// END COMMENTS SECTION ////
}
